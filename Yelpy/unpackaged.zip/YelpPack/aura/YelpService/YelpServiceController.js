({
    doInit: function(component, event, helper) {
        //helper.getYelpData(component);
    },

    updateSearch: function(component, event, helper) {
        helper.getYelpData(component);
    }

})